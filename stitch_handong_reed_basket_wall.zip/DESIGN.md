---
name: Covenant Heritage
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#444653'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#757684'
  outline-variant: '#c4c5d5'
  surface-tint: '#3755c3'
  primary: '#00288e'
  on-primary: '#ffffff'
  primary-container: '#1e40af'
  on-primary-container: '#a8b8ff'
  inverse-primary: '#b8c4ff'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#fe932c'
  on-secondary-container: '#663500'
  tertiary: '#665f3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#b4ab84'
  on-tertiary-container: '#453f20'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001453'
  on-primary-fixed-variant: '#173bab'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#ede3b8'
  tertiary-fixed-dim: '#d1c79d'
  on-tertiary-fixed: '#201c02'
  on-tertiary-fixed-variant: '#4d4727'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  donor-name:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system is built upon the narrative of the "Reed Basket" (Exodus 2:3)—a vessel of protection, providence, and future hope. It balances the academic prestige of a university with the intimate, spiritual reverence of a donor wall. 

The style is **Sophisticated Minimalism** with **Tactile Heritage** accents. It employs expansive whitespace to signify clarity and peace, paired with high-end editorial layouts that treat each donor’s name as a storied legacy. The emotional response is one of gratitude, stability, and belonging to a sacred mission. 

Key visual principles:
- **Reverent Clarity:** Information is presented with breathing room, avoiding clutter to respect the gravity of the contributions.
- **Warm Institutionalism:** Combining the cold authority of deep blues with the organic warmth of golden "basket-weave" tones.
- **Legacy Motion:** Subtle, slow-fade transitions that evoke a sense of timelessness rather than fleeting digital interaction.

## Colors

The palette is anchored in university tradition and biblical symbolism.

- **Primary (Deep Blue):** Represents the academic foundation and the "water" of the Nile upon which the basket floats. Used for structural elements, headers, and primary actions.
- **Accent (Heritage Gold):** Represents the "pitch and tar" that sealed the basket and the light of hope. Used for donor tier highlights, special recognition badges, and soft call-to-actions.
- **Background (Pure/Mist):** Uses #FFFFFF for primary content cards and #F8FAFC for sectional backgrounds to maintain a crisp, airy environment.
- **Semantic Tones:** Success and Information states are derived from the Primary blue, while warnings adopt the Secondary gold to remain cohesive with the brand.

## Typography

This design system utilizes a dual-font strategy to bridge the gap between institutional modernism and personal heritage.

- **The Serif (Noto Serif):** Used for headlines and donor names. It provides a "hand-carved" or "literary" quality that feels permanent and high-end. 
- **The Sans (Inter):** Used for UI labels, navigational elements, and long-form body text. It ensures maximum readability and a clean, contemporary feel.
- **Hierarchy:** Donor names should always be set in the Serif font to differentiate them from the "system" text, providing a human touch. Use ample line-height (1.5x minimum) to ensure a relaxed reading rhythm.

## Layout & Spacing

The layout follows a **Fixed Center Grid** for desktop to evoke the feeling of a physical wall or plaque. 

- **Grid:** A 12-column grid with 24px gutters. Elements usually span 3, 4, 6, or 12 columns.
- **Rhythm:** An 8px base unit governs all padding and margins. 
- **Responsive Behavior:** 
  - **Desktop:** Generous 64px side margins to focus the eye on the center.
  - **Tablet:** Margins reduce to 40px; 12 columns collapse to 8.
  - **Mobile:** Margins reduce to 20px; 12 columns collapse to 4.
- **Whitespace:** Emphasize "Safe Zones" around donor lists. No element should feel crowded; use the `64px` (8 units) spacing for major vertical section breaks.

## Elevation & Depth

To reflect the "Reed Basket" theme, depth is achieved through **Tonal Layering** and **Ambient Shadows** rather than harsh borders.

- **Surface Tiers:** Background is #F8FAFC. Primary content cards use #FFFFFF.
- **Shadows:** Use extremely soft, long-spread shadows. 
  - *Example:* `0px 10px 30px rgba(30, 64, 175, 0.04)`—a faint blue tint in the shadow anchors the element to the university's primary color.
- **Depth Levels:** 
  - **Level 0 (Floor):** Background.
  - **Level 1 (Card):** Floating slightly with a soft shadow. Used for donor name cards.
  - **Level 2 (Active/Modal):** Higher elevation with a secondary glow (#FEF3C7) to indicate selection or special recognition.

## Shapes

The shape language is organic yet controlled. 

- **Corner Radius:** A standard 12px (`rounded-lg`) is used for donor cards and input fields. Larger 24px (`rounded-xl`) radii are used for "search" containers and feature sections to evoke the soft curves of a woven basket.
- **Buttons:** Use fully rounded (pill-shaped) ends for secondary actions to contrast with the more structured rectangular cards.
- **Interactive States:** On hover, cards should subtly scale (1.02x) rather than change color, maintaining a calm visual environment.

## Components

- **Donor Cards:** The core component. Features a white background, 12px rounded corners, and a subtle #1E40AF left-border (4px) for high-tier donors. The name is centered in Noto Serif.
- **Search Bar:** A wide, pill-shaped input with a faint Heritage Gold (#FEF3C7) background. It should feel inviting and easy to use.
- **Tier Chips:** Small, uppercase labels using `label-sm`. Gold backgrounds for "Major Donors," Soft Blue for "Founding Members."
- **Buttons:** 
  - *Primary:* Deep Blue (#1E40AF) with white text. High contrast, sharp but with 8px rounded corners.
  - *Secondary:* Ghost style with a Heritage Gold (#D97706) outline.
- **Lists:** Use staggered grid layouts (Masonry) for donor names to create a more organic, "woven" appearance rather than a strict, rigid table.
- **Progress Bars (Funding Goals):** Use a dual-tone fill. A light gold (#FEF3C7) for the track and the deep blue (#1E40AF) for the progress, symbolizing the water filling the vessel.